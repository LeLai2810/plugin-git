/**
 * Plugin Name: I Love Coding
 * Plugin URI: http://localhost/wordpress
 * Description: Create plugin to add one more �Custom Column� insides Media Library page
 * Version: 1.0 
 * Author: Le Lai
 * Author URI: http://localhost/wordpress
 * License: GPLv2 or later 
*/