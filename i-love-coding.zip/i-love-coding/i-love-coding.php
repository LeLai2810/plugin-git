<?php
/**
 * Plugin Name: I Love Coding
 * Plugin URI: http://localhost/wordpress
 * Description: Create plugin to add one more “Custom Column” insides Media Library page
 * Version: 1.0 
 * Author: Le Lai
 * Author URI: http://localhost/wordpress
 * License: GPLv2 or later 
 */


add_filter('manage_media_columns', 'LL_custom_columns_head');

// ADD NEW COLUMN
function LL_custom_columns_head($posts_columns) {
    $posts_columns['custom_column'] = 'Custom Column';
    return $posts_columns;
}

add_action('manage_media_custom_column', 'LL_custom_columns_content', 10, 2);
// SHOW THE Content
function LL_custom_columns_content($column_name) {
    if ($column_name == 'custom_column') {?>
        <input type="checkbox" name="protected" value="protected" checked> Is it protected<br>
        <a id="click" href="javascript:alert('Hello World');" >Configure private urls</a>
        <?php }

 }

add_action( 'admin_print_styles-upload.php', 'LL_custom_column_css' );

 // Add custom CSS on Media Library 
 
function LL_custom_column_css() {
	echo '<style>
			.custom_column:hover {
			    background-color: violet;
			}
		</style>';
} 



?>
